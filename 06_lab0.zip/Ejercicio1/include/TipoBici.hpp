#ifndef _TIPOBICI_HPP
#define _TIPOBICI_HPP
enum TipoBici {Paseo, Montana}; 
#endif
